/** Automatically generated file. DO NOT MODIFY */
package mais.maltepe.edu.tr;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}